
ALTER TABLE accounts ALTER COLUMN balance TYPE numeric(64, 8);
ALTER TABLE transactions ALTER COLUMN amount TYPE numeric(64, 8);
